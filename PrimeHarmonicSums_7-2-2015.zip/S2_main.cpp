#include "S2.cpp"

using namespace std;

int main() {
    quad_float result = sum1p_and_s2_m1(8);
    cout << result << endl;
}

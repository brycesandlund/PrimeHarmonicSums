#include "special.cpp"

using namespace std;

#define EP 1e-10

int main() {
    quad_float result = phi_s(8);
    cout << result << endl;
}

#include <iostream>
#include "sinterval.cpp"

int main() {
    cout << find_z(to_ftype(4.1666667), true) << endl;
    return 0;
}

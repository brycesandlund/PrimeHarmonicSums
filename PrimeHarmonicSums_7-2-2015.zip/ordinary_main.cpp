#include "ordinary.cpp"

using namespace std;

int main() {
    quad_float result = phi_o(8);
    cout << result << endl;
}
